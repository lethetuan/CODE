<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page' => 'Xem tập tin zip',

        'alert' => [
            'file_is_not_format_archive_zip' => 'Tập tin không phải định dạng zip'
        ]
    ];

?>