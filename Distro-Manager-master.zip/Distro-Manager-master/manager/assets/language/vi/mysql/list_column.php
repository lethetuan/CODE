<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page' => 'Danh sách cột',

        'alert' => [
            'empty_list_column' => 'Không có cột nào'
        ]
    ];

?>