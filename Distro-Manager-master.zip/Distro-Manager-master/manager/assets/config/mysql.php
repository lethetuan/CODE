<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'mysql_host'       => 'localhost',
        'mysql_username'   => 'root',
        'mysql_password'   => '',
        'mysql_name'       => '',
        'mysql_port'       => '3306',
        'mysql_improved'   => true,
        'mysql_is_connect' => false
    ];

?>